//
//  ViewController.h
//  SuperKoalio
//

//  Copyright (c) 2013 Razeware, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import <iAd/iAd.h>


@interface ViewController : UIViewController <ADBannerViewDelegate>

@property IBOutlet UIImageView*a;
@end
