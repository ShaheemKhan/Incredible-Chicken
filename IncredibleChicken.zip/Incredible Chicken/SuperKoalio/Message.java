package com.example.lecture4;
import java.util.HashMap;
import java.io.Serializable;

@SuppressWarnings("serial")
public class Message implements Serializable {

	Header h;
	Body b;
	
	Message() {
		h = new Header(null, null);
		b = new Body();
	}
	
	
	public class Header implements Serializable {
		String id;
		Long seqNo;
		String retId;
		String type;
		
		Header(String i, String t) {
			id = i;
			seqNo = (long) 0;
			retId = id;
			type = t;
		}
	}
	
	public class Body implements Serializable {
		HashMap<Integer, String> map;
		
		Body () {
			map = new HashMap<Integer, String> ();
		}
	}
	
	public void createConnectionMessage(String i) {
		h = new Header(i, "String");
		b = new Body();
		b.map.put(b.map.size(), "Logging in");
	}
	
	public void listFiles(String i) {
		h = new Header(i, "String");
		b = new Body();
		b.map.put(b.map.size(), "List files");
	}
	
	public void createLoginResponse() {
		h = new Header("Server", "String");
		b = new Body();
		b.map.put(b.map.size(), "Logged in");
	}
	
	public void sendList(HashMap<Integer, String> m) {
		h = new Header("Server", "String");
		b = new Body();
		b.map = m;
	}
	
}
