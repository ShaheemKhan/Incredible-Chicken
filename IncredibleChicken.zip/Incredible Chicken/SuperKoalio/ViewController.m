//
//  ViewController.m
//  SuperKoalio
//
//  Created by Jake Gundersen on 12/27/13.
//  Copyright (c) 2013 Razeware, LLC. All rights reserved.
//

#import "ViewController.h"
#import "MainMenu.h"
#import "GameLevelScene.h"

@implementation ViewController

@synthesize a;

- (void)viewDidAppear:(BOOL)animated
{
  
  
  [super viewDidAppear:animated];
  
  // Configure the view.
  SKView * skView = (SKView *)self.view;
  
  if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
    // iOS 7
    [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
  } else {
    // iOS 6
    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
  }
  
  // Create and configure the scene.
  SKScene * scene = [GameLevelScene sceneWithSize:skView.bounds.size];
  scene.scaleMode = SKSceneScaleModeAspectFill;
  
  // Present the scene.
  [skView presentScene:scene];
  
  a.hidden = YES;
}


- (BOOL)prefersStatusBarHidden {
  return YES;
}


- (BOOL)shouldAutorotate
{
  return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
  return UIInterfaceOrientationMaskLandscape;
}

- (void)didReceiveMemoryWarning
{
  [super didReceiveMemoryWarning];
  // Release any cached data, images, etc that aren't in use.
}

- (void) bannerViewDidLoadAd:(ADBannerView *)banner {
  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:1];
  [banner setAlpha:1];
  [UIView commitAnimations];
}

- (void) bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error {
  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:1];
  [banner setAlpha:0];
  [UIView commitAnimations];
}


@end
