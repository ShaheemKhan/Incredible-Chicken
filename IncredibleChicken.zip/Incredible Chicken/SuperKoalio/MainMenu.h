//
//  MainMenu.h
//  SuperKoalio
//
//  Created by Shaheem Khan on 2/17/2014.
//  Copyright (c) 2014 Razeware. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <iAd/iAd.h>

@interface MainMenu : UIViewController <ADBannerViewDelegate> 


@end
