//
//  GameLevelScene.m
//  SuperKoalio
//
//  Created by Jake Gundersen on 12/27/13.
//  Copyright (c) 2013 Razeware, LLC. All rights reserved.
//

#import "GameLevelScene.h"
#import "MainMenu.h"
#import "JSTileMap.h"
#import "Player.h"
#import "SKTAudio.h"
#import "SKTUtils.h"

@interface GameLevelScene()

@property (nonatomic, strong) JSTileMap *map;
@property (nonatomic, strong) Player *player;
@property (nonatomic, assign) NSTimeInterval previousUpdateTime;
@property (nonatomic, strong) TMXLayer *walls;
@property (nonatomic, strong) TMXLayer *hazards;
@property (nonatomic, strong) TMXLayer *point;
@property int a;
@property int b;
@property int x;
@property int score;
@property (strong, nonatomic) SKLabelNode *scoreLabel;
@property (strong, nonatomic) SKLabelNode *hsLabel;
@property (nonatomic, assign) BOOL gameOver;
@property UIButton *replay;
@end

@implementation GameLevelScene

@synthesize replay;

-(int)getRandomNumberBetween:(int)from to:(int)to {
  return (int)from + arc4random() % (to-from+1);
}

-(id)initWithSize:(CGSize)size {
  
  
  if (self = [super initWithSize:size]) {
  
    int k = [self getRandomNumberBetween:1 to:2];
    if (k == 1) {
      SKTexture *backgroundTexture = [SKTexture textureWithImageNamed:@"bcs.png"];
      SKSpriteNode *background = [SKSpriteNode spriteNodeWithTexture:backgroundTexture size:self.view.frame.size];
      background.position = (CGPoint) {CGRectGetMidX(self.view.frame), CGRectGetMidY(self.view.frame)};
      [self addChild:background];
    }
    else {
      self.backgroundColor = [SKColor colorWithRed:0.0 green:0.60 blue:0.82 alpha:0.0];
    }
    
    self.scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"Marker Felt"];
    self.scoreLabel.text = @"0";
    self.scoreLabel.zPosition = 4;
    self.scoreLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeLeft;
    self.scoreLabel.position = CGPointMake(size.width/2, size.height-60);
    self.scoreLabel.fontColor = [UIColor whiteColor];
    [self addChild:self.scoreLabel];
    
    NSUserDefaults *defaultsHighScore = [NSUserDefaults standardUserDefaults];
    NSString *loadHighScore1 = [defaultsHighScore objectForKey: @"hs"];
    
    NSLog(@"%@", loadHighScore1);
    if (loadHighScore1.length == 0) {

      NSString *SaveHighScore = [NSString stringWithFormat: @"%d",0];
      NSUserDefaults *defaultsHighScore = [NSUserDefaults standardUserDefaults];
      [defaultsHighScore setObject:SaveHighScore forKey:@"hs"];
      [defaultsHighScore synchronize];
      
      NSString *medal = [NSString stringWithFormat: @"0"];
      NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
      [medalStore setObject:medal forKey:@"m"];
      [medalStore synchronize];
    }
    defaultsHighScore = [NSUserDefaults standardUserDefaults];
    loadHighScore1 = [defaultsHighScore objectForKey: @"hs"];
    
    self.hsLabel = [SKLabelNode labelNodeWithFontNamed:@"Marker Felt"];
    self.hsLabel.text = [NSString stringWithFormat:@"Highscore: %@", loadHighScore1];
    self.hsLabel.zPosition = 4;
    self.hsLabel.horizontalAlignmentMode = SKLabelHorizontalAlignmentModeLeft;
    if (self.size.width == 568)
      self.hsLabel.position = CGPointMake((568/2)+185, size.height-50);
    else
      self.hsLabel.position = CGPointMake(380, size.height-50);
    self.hsLabel.fontColor = [UIColor whiteColor];
    self.hsLabel.fontSize = 16;
    [self addChild:self.hsLabel];
    
    
    int r = [self getRandomNumberBetween:1 to:5];
    self.map = [JSTileMap mapNamed:[NSString stringWithFormat:@"level%d.tmx", r]];
       [self addChild:self.map];
    self.walls = [self.map layerNamed:@"walls"];
    self.hazards = [self.map layerNamed:@"hazards"];
    self.point = [self.map layerNamed:@"point"];
    self.x = 0;
    self.a = true;
    
    self.a = 0;
    self.player = [[Player alloc] initWithImageNamed:@"ce1.png"];
    self.player.position = CGPointMake(100, 50);
    self.player.zPosition = 15;
    [self.map addChild:self.player];
    
    self.userInteractionEnabled = YES;
  }
  return self;

}

- (void) imageUpdate {
  self.a++;
  if(self.a == 11)
    self.a = 1;
  SKTexture* changeFace = [SKTexture textureWithImageNamed:[NSString stringWithFormat:@"ce%d.png", self.a]];
  self.player.texture = changeFace;
}

- (void)update:(NSTimeInterval)currentTime
{
  
  self.replay.hidden = NO;
  if (self.gameOver) return;
  
  NSTimeInterval delta = currentTime - self.previousUpdateTime;
  
  if (delta > 0.02) {
    delta = 0.02;
  }
  
  self.b++;
  if(self.b == 6) {
    self.b = 0;
    [self imageUpdate];
  }
  self.previousUpdateTime = currentTime;
  [self.player update:delta];
  
  [self checkForAndResolveCollisionsForPlayer:self.player forLayer:self.walls];
  [self handleHazardCollisions:self.player];
  [self handlePointCollisions:self.player];
  [self checkForWin];
  [self setViewpointCenter:self.player.position];
}

-(void) updateScore {
  if (self.x > self.score) {
    self.score++;
   // [self runAction:[SKAction playSoundFileNamed:@"coin.wav" waitForCompletion:NO]];
    self.x = self.score;
    self.scoreLabel.text = [NSString stringWithFormat: @"%d", self.score];
  }
}

-(CGRect)tileRectFromTileCoords:(CGPoint)tileCoords
{
  float levelHeightInPixels = self.map.mapSize.height * self.map.tileSize.height;
  CGPoint origin = CGPointMake(tileCoords.x * self.map.tileSize.width, levelHeightInPixels - ((tileCoords.y + 1) * self.map.tileSize.height));
  return CGRectMake(origin.x, origin.y, self.map.tileSize.width, self.map.tileSize.height);
}

- (NSInteger)tileGIDAtTileCoord:(CGPoint)coord forLayer:(TMXLayer *)layer
{
  TMXLayerInfo *layerInfo = layer.layerInfo;
  return [layerInfo tileGidAtCoord:coord];
}

- (void)checkForAndResolveCollisionsForPlayer:(Player *)player forLayer:(TMXLayer *)layer
{
  NSInteger indices[8] = {7, 1, 3, 5, 0, 2, 6, 8};
  player.onGround = NO; 
  for (NSUInteger i = 0; i < 8; i++) {
    NSInteger tileIndex = indices[i];
    
    CGRect playerRect = [player collisionBoundingBox];
    CGPoint playerCoord = [layer coordForPoint:player.desiredPosition];
    
    if (playerCoord.y >= self.map.mapSize.height - 1) {
      [self gameOver: 0];
      return;
    }
    
    NSInteger tileColumn = tileIndex % 3;
    NSInteger tileRow = tileIndex / 3;
    CGPoint tileCoord = CGPointMake(playerCoord.x + (tileColumn - 1), playerCoord.y + (tileRow - 1));
    
    NSInteger gid = [self tileGIDAtTileCoord:tileCoord forLayer:layer];
    if (gid != 0) {
      CGRect tileRect = [self tileRectFromTileCoords:tileCoord];
      //NSLog(@"GID %ld, Tile Coord %@, Tile Rect %@, player rect %@", (long)gid, NSStringFromCGPoint(tileCoord), NSStringFromCGRect(tileRect), NSStringFromCGRect(playerRect));
      //1
      if (CGRectIntersectsRect(playerRect, tileRect)) {
        CGRect intersection = CGRectIntersection(playerRect, tileRect);
        //2
        if (tileIndex == 7) {
          //tile is directly below Koala
          player.desiredPosition = CGPointMake(player.desiredPosition.x, player.desiredPosition.y + intersection.size.height);
          
          self.player.forwardMarch = YES;
          player.velocity = CGPointMake(player.velocity.x, 0.0);
          
          player.onGround = YES;
        } else if (tileIndex == 1) {
          //tile is directly above Koala
          player.desiredPosition = CGPointMake(player.desiredPosition.x, player.desiredPosition.y - intersection.size.height);
        } else if (tileIndex == 3) {
          //tile is left of Koala
          player.desiredPosition = CGPointMake(player.desiredPosition.x + intersection.size.width, player.desiredPosition.y);
        } else if (tileIndex == 5) {
          //tile is right of Koala
          player.desiredPosition = CGPointMake(player.desiredPosition.x - intersection.size.width, player.desiredPosition.y);
          //3
        } else {
          if (intersection.size.width > intersection.size.height) {
            //tile is diagonal, but resolving collision vertically
            //4
            player.velocity = CGPointMake(player.velocity.x, 0.0); ////Here
            float intersectionHeight;
            if (tileIndex > 4) {
              intersectionHeight = intersection.size.height;
              player.onGround = YES; ////Here
            } else {
              intersectionHeight = -intersection.size.height;
            }
            player.desiredPosition = CGPointMake(player.desiredPosition.x, player.desiredPosition.y + intersection.size.height );
          } else {
            //tile is diagonal, but resolving horizontally
            float intersectionWidth;
            if (tileIndex == 6 || tileIndex == 0) {
              intersectionWidth = intersection.size.width;
            } else {
              intersectionWidth = -intersection.size.width;
            }
            //5
            player.desiredPosition = CGPointMake(player.desiredPosition.x  + intersectionWidth, player.desiredPosition.y);
          }
        }
      }
    }
  }
  //6
  player.position = player.desiredPosition;
}

- (void)handleHazardCollisions:(Player *)player
{
  if (self.gameOver) {
    [self runAction:[SKAction playSoundFileNamed:@"death2.wav" waitForCompletion:NO]];
    return;
  }
  NSInteger indices[8] = {7, 1, 3, 5, 0, 2, 6, 8};

  for (NSUInteger i = 0; i < 8; i++) {
    NSInteger tileIndex = indices[i];
    
    CGRect playerRect = [player collisionBoundingBox];
    CGPoint playerCoord = [self.hazards coordForPoint:player.desiredPosition];
    
    NSInteger tileColumn = tileIndex % 3;
    NSInteger tileRow = tileIndex / 3;
    CGPoint tileCoord = CGPointMake(playerCoord.x + (tileColumn - 1), playerCoord.y + (tileRow - 1));
    
    NSInteger gid = [self tileGIDAtTileCoord:tileCoord forLayer:self.hazards];
    if (gid != 0) {
      CGRect tileRect = [self tileRectFromTileCoords:tileCoord];
      if (CGRectIntersectsRect(playerRect, tileRect)) {
        [self gameOver:0];
      }
    }
  }
}

- (void)handlePointCollisions:(Player *)player {
  
  if (self.gameOver) return;
  NSInteger indices[8] = {7, 1, 3, 5, 0, 2, 6, 8};
  
  for (NSUInteger i = 0; i < 8; i++) {
    NSInteger tileIndex = indices[i];
    
    CGRect playerRect = [player collisionBoundingBox];
    CGPoint playerCoord = [self.hazards coordForPoint:player.desiredPosition];
    
    NSInteger tileColumn = tileIndex % 3;
    NSInteger tileRow = tileIndex / 3;
    CGPoint tileCoord = CGPointMake(playerCoord.x + (tileColumn - 1), playerCoord.y + (tileRow - 1));
    
    NSInteger gid = [self tileGIDAtTileCoord:playerCoord forLayer:self.point];
    if (gid != 0) {
      CGRect tileRect = [self tileRectFromTileCoords:tileCoord];
      if (CGRectIntersectsRect(playerRect, tileRect)) {
        self.x++;
      
      }
    }
    else {
      [self updateScore];
    }
  }
}





-(void)checkForWin {
  if (self.player.position.x > 9567.0) {
    [self gameOver:1];
  }
}

-(Boolean) highhs {
  NSUserDefaults *defaultsHighScore = [NSUserDefaults standardUserDefaults];
  NSString *loadHighScore = [defaultsHighScore objectForKey: @"hs"];
  int hs = [loadHighScore intValue];
  
  if (hs < self.score){
    NSString *SaveHighScore = [NSString stringWithFormat: @"%d",self.score];
    NSUserDefaults *defaultsHighScore = [NSUserDefaults standardUserDefaults];
    [defaultsHighScore setObject:SaveHighScore forKey:@"hs"];
    [defaultsHighScore synchronize];
    return true;
  }
  
  return false;
}

-(void)gameOver:(BOOL)won {
  self.gameOver = YES;
  if(won == 1) {
    SKLabelNode *endGameLabel = [SKLabelNode labelNodeWithFontNamed:@"Marker Felt"];
    endGameLabel.fontColor = [UIColor whiteColor];
    endGameLabel.text = @"Congratulations you finished the game";
    endGameLabel.fontSize = 20;
    NSLog (@"cassa %f", self.size.width);
    endGameLabel.position = CGPointMake((self.size.width / 2.0)-20, (self.size.height / 2)+75);
    [self addChild:endGameLabel];
    
  }
  
  
  [self highhs];
  
  NSUserDefaults *defaultsHighScore = [NSUserDefaults standardUserDefaults];
  NSString *loadHighScore1 = [defaultsHighScore objectForKey: @"hs"];
  int highscore = [loadHighScore1 intValue];
  
  
  if (highscore < 15) {
    NSString *medal = @"0";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  if (highscore > 15) {
    NSString *medal = @"4";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 30) {
    NSString *medal = @"5";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 45) {
    NSString *medal = @"6";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 60) {
    NSString *medal = @"1";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  if (highscore > 100) {
    NSString *medal = @"2";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 140) {
    NSString *medal = @"3";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 170) {
    NSString *medal = @"7";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 200) {
    NSString *medal = @"8";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 230) {
    NSString *medal = @"9";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  if (highscore > 260) {
    NSString *medal = @"10";
    NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
    [medalStore setObject:medal forKey:@"m"];
    [medalStore synchronize];
  }
  
  [self runAction:[SKAction playSoundFileNamed:@"death2.wav" waitForCompletion:NO]];


  SKSpriteNode *fireNode = [SKSpriteNode spriteNodeWithImageNamed:@"replay.jpg"];
  fireNode.position = CGPointMake(self.size.width / 2.0, (self.size.height / 2.0) - 90);
  fireNode.name = @"fireButtonNode";//how the node is identified later
  fireNode.zPosition = 1.0;
  [self addChild:fireNode];
  
  
  NSUserDefaults *medalStore = [NSUserDefaults standardUserDefaults];
  NSString *medal = [medalStore objectForKey: @"m"];
  
  NSLog(@"rewqrewrew %@", medal);
  
  
  SKSpriteNode *highNode = [SKSpriteNode spriteNodeWithImageNamed:[NSString stringWithFormat: @"S%@", medal]];
  highNode.position = CGPointMake(self.size.width / 2.0,(self.size.height / 2)+10);
  [self addChild: highNode];
  
  
  SKLabelNode *endGameLabel = [SKLabelNode labelNodeWithFontNamed:@"Marker Felt"];
  endGameLabel.fontColor = [UIColor whiteColor];
  endGameLabel.text = loadHighScore1;
  endGameLabel.fontSize = 26;
  NSLog (@"cassa %f", self.size.width);
  endGameLabel.position = CGPointMake((self.size.width / 2.0)+70, (self.size.height / 2)-40);
  [self addChild:endGameLabel];
  
  SKLabelNode *score = [SKLabelNode labelNodeWithFontNamed:@"Marker Felt"];
  score.fontColor = [UIColor whiteColor];
  score.text = [NSString stringWithFormat: @"%d", self.score];
  score.fontSize = 26;
  score.position = CGPointMake((self.size.width / 2.0) +70, (self.size.height / 1.7)-20);
  [self addChild:score];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
  self.player.mightAsWellJump = YES;
  UITouch *touch = [touches anyObject];
  CGPoint location = [touch locationInNode:self];
  SKNode *node = [self nodeAtPoint:location];
  
  //if fire button touched, bring the rain
  if ([node.name isEqualToString:@"fireButtonNode"]) {
      [self.view presentScene:[[GameLevelScene alloc] initWithSize:self.size]];
  }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
  self.player.mightAsWellJump = NO;
}

- (void)setViewpointCenter:(CGPoint)position {
  NSInteger x = MAX(position.x, self.size.width / 2);
  NSInteger y = MAX(position.y, self.size.height / 2);
  x = MIN(x, (self.map.mapSize.width * self.map.tileSize.width) - self.size.width / 2);
  y = MIN(y, (self.map.mapSize.height * self.map.tileSize.height) - self.size.height / 2);
  CGPoint actualPosition = CGPointMake(x, y);
  CGPoint centerOfView = CGPointMake(self.size.width/2, self.size.height/2);
  CGPoint viewPoint = CGPointSubtract(centerOfView, actualPosition);
  self.map.position = viewPoint;
}



@end
